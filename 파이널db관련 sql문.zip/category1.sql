insert into MY_TABLE (category1code, category1name)
values  (1, '사무용품'),
        (2, '가구'),
        (4, '사무기기'),
        (3, '인테리어 소품'),
        (5, '기타');